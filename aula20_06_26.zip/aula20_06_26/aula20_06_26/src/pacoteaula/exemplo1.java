package pacoteaula;

import java.sql.SQLOutput;
import java.util.Scanner;

public class exemplo1 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);

        String nome;
        int idade;
        double ponto;
        boolean verdadeiro_falso;
        char caractere;

        System.out.println("Qual é o seu nome?");
        nome = leia.nextLine();
        System.out.print("Ok, seu nome é " + nome);
        System.out.println(" Informe sua idade: ");
        idade = leia.nextInt();

        System.out.println(" 1 - cadastrar 2 - listar 3 - sair ");
        int opcao = leia.nextInt();
        switch (opcao){
            case 1:

                break;
                System.out.println("Cadastro realizado");
            case 2:

                break;
                System.out.println(" lista de cadastro ");
            case 3:

                break;
                System.out.println("Encerrando");

                break;
            default:
                System.out.println("Nenhuma opção escolhida ou formato invalido");

                break;
        }



        /*
        int opcao = 0;

        do {
        System.out.println(" 1 - cadastrar 2 - listar 3 - sair ");
        opcao = leia.nextInt();
        }while (opcao !=3);
         */




        /*
        int opcao= 0;

        while (opcao !=3 ){
            System.out.println(" 1 - cadastrar 2 - listar 3 - sair ");
            opcao = leia.nextInt();
        }


        /*
        if ( idade >= 18) {
            System.out.println("Você é maior de idade ");
        } else {
            System.out.println("Você é menor de idade ");


        }


    }
}
